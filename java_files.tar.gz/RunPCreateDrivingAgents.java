package matsim;

import org.matsim.api.core.v01.Coord;
import org.matsim.api.core.v01.Id;
import org.matsim.api.core.v01.Scenario;
import org.matsim.api.core.v01.population.Activity;
import org.matsim.api.core.v01.population.Leg;
import org.matsim.api.core.v01.population.Person;
import org.matsim.api.core.v01.population.Plan;
import org.matsim.api.core.v01.population.Population;
import org.matsim.core.config.Config;
import org.matsim.core.config.ConfigUtils;
import org.matsim.core.config.groups.PlanCalcScoreConfigGroup.ActivityParams;
import org.matsim.core.controler.Controler;
import org.matsim.core.controler.OutputDirectoryHierarchy;
import org.matsim.core.network.io.MatsimNetworkReader;
import org.matsim.core.scenario.ScenarioUtils;

public class RunPCreateDrivingAgents {

	public static void main(String[] args) {
		Config config = ConfigUtils.createConfig();

		config.controler().setLastIteration(0);

		ActivityParams home = new ActivityParams("home");
		home.setTypicalDuration(16 * 60 * 60);
		config.planCalcScore().addActivityParams(home);
		
		ActivityParams work = new ActivityParams("work");
		work.setTypicalDuration(4 * 60 * 60);
		
		ActivityParams ebed = new ActivityParams("ebed");
		ebed.setTypicalDuration(0.15 * 60 * 60);
		
		ActivityParams tanuloszoba = new ActivityParams("tanuloszoba");
		tanuloszoba.setTypicalDuration(2 * 60 * 60);
		
		config.planCalcScore().addActivityParams(ebed);
		config.planCalcScore().addActivityParams(work);
		config.planCalcScore().addActivityParams(tanuloszoba);

		Scenario scenario = ScenarioUtils.createScenario(config);

		new MatsimNetworkReader(scenario.getNetwork()).readFile("/home/matsim/Downloads/output.xml"); // TODO set this to your osm network
		// TODO the output will be in eclipse-workspace/matsimartifact/output, we only need the output_plans.xml.gz
		
		fillScenario(scenario);

		Controler controler = new Controler(scenario);
		controler.getConfig().controler().setOverwriteFileSetting(
				true ?
						OutputDirectoryHierarchy.OverwriteFileSetting.overwriteExistingFiles :
						OutputDirectoryHierarchy.OverwriteFileSetting.failIfDirectoryExists );
		
		controler.run();


	}

	private static Population fillScenario(Scenario scenario) {
		Population population = scenario.getPopulation();
		// one agent 
		for (int i = 0; i < 499; i++) {
			// TODO set these coordinates to ones that are on your network (you can check it with Via)
			//home 806107.6576718253" y="5265468.432542688"
			//work x="805892.6129934189" y="5265612.527900451"
			Coord coordHome = new Coord(806107 + i*10, 5265468+i*10);
			Coord coordWork = new Coord(805892-i*10, 5265612-i*10);
			createOnePerson(scenario, population, i, coordHome, coordWork);
		}

		return population;
	}

	// TODO you don't need to change this function
	private static void createOnePerson(Scenario scenario,
		Population population, int i, Coord coord, Coord coordWork) {
		Person person = population.getFactory().createPerson(Id.createPersonId("p_"+i));

		Plan plan = population.getFactory().createPlan();

		Activity home = population.getFactory().createActivityFromCoord("home", coord);
		home.setEndTime(8*60*60);
		plan.addActivity(home);

		Leg hinweg = population.getFactory().createLeg("car");
		plan.addLeg(hinweg);

		Activity work = population.getFactory().createActivityFromCoord("work", coordWork);
		work.setEndTime(12*60*60);
		plan.addActivity(work);

		Leg rueckweg = population.getFactory().createLeg("car");
		plan.addLeg(rueckweg);

		Activity home2 = population.getFactory().createActivityFromCoord("home", coord);
		plan.addActivity(home2);

		person.addPlan(plan);
		population.addPerson(person);
	}

}

